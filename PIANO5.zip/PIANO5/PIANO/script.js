
//baixar 5 sons
function show1(){
    var snd = new Audio("./sonido1.mp3");
    snd.play();
}

function show2(){
    var snd = new Audio("./sonido2.mp3");
    snd.play();
}

function show3(){
    var snd = new Audio("./sonido3.mp3");
    snd.play();
}

function show4(){
    var snd = new Audio("./sonido4.mp3");
    snd.play();
}

function show5(){
    var snd = new Audio("./sonido5.mp3");
    snd.play();
}

function show6(){
    var snd = new Audio("./sonidocuerda.mp3");
    snd.play();
}
function show7(){
    var snd = new Audio("./bangfnal.mp3");
    snd.play();
}
function show8(){
    var snd = new Audio("./woosh.mp3");
    snd.play();
}
function show9(){
    var snd = new Audio("./clap.mp3");
    snd.play();
}
function show10(){
    var snd = new Audio("./cymbal.mp3");
    snd.play();
}
function show11(){
    var snd = new Audio("./drum.mp3");
    snd.play();
}



var snd1 = new Audio("./eot2.mp3");
function canço1(){
    
    snd1.play();
}
var snd2 = new Audio("./eot3.mp3");
function canço2(){
    
    snd2.play();
}
var snd3 = new Audio("./tfc2.mp3");
function canço3(){
    
    snd3.play();
}
var snd4 = new Audio("./tfc3.mp3");
function canço4(){
    
    snd4.play();
}
var snd5 = new Audio("./blv2.mp3");
function canço5(){
    
    snd5.play();
}
var snd6 = new Audio("./blv3.mp3");
function canço6(){
    
    snd6.play();
}
var snd7 = new Audio("./mix.mp3");
function mix(){
    
    snd7.play();
} 
function pausa1(){
    snd1.pause();
    snd2.pause();
    snd3.pause();
    snd4.pause();
    snd5.pause();
    snd6.pause();
    snd7.pause();
}
let configTeclat = {prevent_repeat : true};
let eventTeclat = new window.keypress.Listener(this,configTeclat);

eventTeclat.simple_combo('a',show1);
eventTeclat.simple_combo('s',show2);
eventTeclat.simple_combo('d',show3);
eventTeclat.simple_combo('q',show4);
eventTeclat.simple_combo('g',show5);
eventTeclat.simple_combo('h',show6);
eventTeclat.simple_combo('j',show7);
eventTeclat.simple_combo('k',show8);
eventTeclat.simple_combo('w',show9);
eventTeclat.simple_combo('z',show10);
eventTeclat.simple_combo('x',show11);
eventTeclat.sequence_combo('e b t',mix);
eventTeclat.simple_combo('p',pausa1)


//fer 3 bases de cançons llargues amb 5 mini audios i fer cançons. 3 cançons amb sequence combo